export class Proizvod{
    naziv: string;
    kolicina: number;
    komentari: Array<Object>;
    zaKupovinu: boolean;
}