import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'

@Injectable({
  providedIn: 'root'
})
export class KorisnikService {

  uri = 'http://localhost:4000';

  constructor(private http: HttpClient) { }

  prijavaNaSistem(kor_ime, lozinka){
    const data={
      kor_ime: kor_ime,
      lozinka: lozinka
    }
    return this.http.post(`${this.uri}/prijavaNaSistem`, data);
  }

  dohvatiKorisnikaPoKorisnickomImenu(kor_ime){
    const data={
      kor_ime: kor_ime
    }
    return this.http.post(`${this.uri}/dohvatiKorisnikaPoKorisnickomImenu`, data);
  }
}
